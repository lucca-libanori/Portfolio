function mudaPagina1() {

    window.location.href ="paginas/video1.html";

}

function mudaPagina2() {

    window.location.href ="paginas/formulario.php";
    
}

function mudaPagina3() {

    window.location.href ="paginas/imagens.html";
    
}

function mudaPagina4() {

    window.location.href ="paginas/sobre.html";
  
}
