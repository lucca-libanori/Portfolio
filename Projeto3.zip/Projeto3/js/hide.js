$(document).ready(function(){
    $("#video1").hide();
    $("#toggle").click(function(){
      $("#video1").toggle();
    });
});
  
$(document).ready(function(){
    $("#video2").hide();
    $("#toggle2").click(function(){
      $("#video2").toggle();
    });
});
  
$(document).ready(function(){
    $("#video3").hide();
    $("#toggle3").click(function(){
      $("#video3").toggle();
    });
});


$(document).ready(function(){
    $("#video4").hide();
    $("#toggle4").click(function(){
      $("#video4").toggle();
    });
});
  
$(document).ready(function(){
    $("#video5").hide();
    $("#toggle5").click(function(){
      $("#video5").toggle();
    });
});
  
$(document).ready(function(){
    $("#video6").hide();
    $("#toggle6").click(function(){
      $("#video6").toggle();
    });
});
  
$(document).ready(function(){
    $("#video7").hide();
    $("#toggle7").click(function(){
      $("#video7").toggle();
    });
});
  
$(document).ready(function(){
    $("#video8").hide();
    $("#toggle8").click(function(){
      $("#video8").toggle();
    });
});
  
$(document).ready(function(){
    $("#video9").hide();
    $("#toggle9").click(function(){
      $("#video9").toggle();
    });
});
  
$(document).ready(function(){
    $("#video10").hide();
    $("#toggle10").click(function(){
      $("#video10").toggle();
    });
});